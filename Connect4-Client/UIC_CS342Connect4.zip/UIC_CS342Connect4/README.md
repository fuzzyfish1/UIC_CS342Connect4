# UIC_CS342Connect4
project done by: Angad Ghakal, and Zain Ali <br>
Class: UIC CS 342, Software Design

# Connect 4
connect 4 is supposed to be a board logic where 2 players take turns dropping colored coins into slots
A player wins when they can connect 4 of their coins in a straight line diagonally, vertically, or horizontally<br>

# UML diagram
We used lucid chart to create our diagram using UML ** insert number **<br>
<a href = "https://lucid.app/lucidchart/283a3a7b-d015-42a5-be5f-e0ad062d993c/edit?viewport_loc=7%2C-156%2C1331%2C587%2C0_0&invitationId=inv_145cd703-34fa-44e9-802b-7c5aba1e474a"> Link</a>

# Our Game
Our logic is 2 player<br>
Our server can host multiple games simultaneously<br>
Server must be run locally<br>
<br>

<i>!Have Fun!</i>