package lib;

public enum status {

	  WIN, LOSE, TIE, RUNNING, START, WAITING, REMATCH
}
