package logic;

import javafx.stage.Stage;

public class Globals {

    public static class temp {
        public static int port = -1;
        public static Stage primaryStage = null;
    }

    public static class constants {
        public static final int width = 7;
        public static final int height = 6;
    }

}
